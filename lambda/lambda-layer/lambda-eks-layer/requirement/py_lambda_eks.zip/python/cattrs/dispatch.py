from cattr.dispatch import FunctionDispatch, MultiStrategyDispatch

__all__ = ["FunctionDispatch", "MultiStrategyDispatch"]
